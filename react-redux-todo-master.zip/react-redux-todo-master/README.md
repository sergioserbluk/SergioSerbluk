# Ejemplo react redux todo list

Este pequeńo projecto fue creado como una guía para el curso Visual studio code en [Udemy](https://www.udemy.com/course/se-un-programador-mas-productivo-con-visual-studio-code/learn/lecture/13298166#overview), el codigo del repositorio es solo una referencia para desenvolverse con el editor de texto y git.

## Como correr el proyecto

Para visualizar la aplicación, debes seguir los siguientes pasos:

### Instalar dependencias

Corre `npm i o yarn` en tu terminal

### Visualizar la applicaion

Corre `npm start o yarn start` en tu terminal.<br>
Dirigete a [http://localhost:3000](http://localhost:3000) en tu navegador.

La pagina recarga automaticamente cuando salvamos.<br>


